"""Build the project presentation from REAL results (no hand-typed numbers).

    python scripts/make_pptx.py --author "Your Name" --course "Deep Learning"
Needs: results/metrics.json (train.py + scripts/evaluate.py), plus optional
results/confusion_matrix.png, results/training_curves.png and ../public/samples/*.jpg.
"""
import argparse
import json
import sys
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parent.parent
INK, MUTE, ACC, SOFT, BG = (RGBColor(0x1C, 0x1B, 0x18), RGBColor(0x6C, 0x6A, 0x63),
                            RGBColor(0xC2, 0x41, 0x0C), RGBColor(0xFE, 0xD7, 0xAA), RGBColor(0xFB, 0xFA, 0xF7))


def text(slide, x, y, w, h, s, size=18, bold=False, color=INK, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
    for i, line in enumerate(s if isinstance(s, list) else [s]):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        para.alignment = align; para.space_after = Pt(8)
        r = para.add_run(); r.text = line
        r.font.size, r.font.bold, r.font.color.rgb, r.font.name = Pt(size), bold, color, "Calibri"
    return tb


def box(slide, x, y, w, h, fill=SOFT, line=None):
    s = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    s.adjustments[0] = 0.08; s.fill.solid(); s.fill.fore_color.rgb = fill
    if line: s.line.color.rgb = line
    else: s.line.fill.background()
    s.shadow.inherit = False
    return s


def stat(slide, x, y, w, value, label):
    box(slide, x, y, w, 1.35)
    text(slide, x, y + 0.12, w, 0.7, value, 30, True, ACC, PP_ALIGN.CENTER)
    text(slide, x, y + 0.85, w, 0.4, label, 13, False, MUTE, PP_ALIGN.CENTER)


def new_slide(prs, title, notes=""):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    s.background.fill.solid(); s.background.fill.fore_color.rgb = BG
    bar = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(0.25), prs.slide_height)
    bar.fill.solid(); bar.fill.fore_color.rgb = ACC; bar.line.fill.background()
    if title: text(s, 0.8, 0.45, 11.5, 0.9, title, 32, True)
    if notes: s.notes_slide.notes_text_frame.text = notes
    return s


def pic(slide, path, x, y, w=None, h=None):
    if Path(path).is_file():
        slide.shapes.add_picture(str(path), Inches(x), Inches(y), Inches(w) if w else None, Inches(h) if h else None)
        return True
    return False


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results", default=str(ROOT / "results"))
    p.add_argument("--out", default=str(ROOT / "docs" / "Cats_vs_Dogs_Project.pptx"))
    p.add_argument("--author", required=True)
    p.add_argument("--course", default="Deep Learning")
    a = p.parse_args()

    res = Path(a.results)
    mfile = res / "metrics.json"
    if not mfile.is_file():
        sys.exit("results/metrics.json not found. Run train.py and scripts/evaluate.py first - "
                 "this deck only uses real measured results.")
    m = json.loads(mfile.read_text())
    missing = [k for k in ("test_accuracy", "precision", "recall", "f1_score", "epochs", "parameters") if k not in m]
    if missing:
        sys.exit(f"metrics.json is missing {missing}. Run: python scripts/evaluate.py")

    links = json.loads((ROOT.parent / "lib" / "project-data.json").read_text())["links"]
    pc = lambda v: f"{v * 100:.1f}%"

    prs = Presentation(); prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)

    s = new_slide(prs, "", f"Introduce yourself and the goal: classify a photo as cat or dog. Result: {pc(m['test_accuracy'])} test accuracy.")
    text(s, 0.8, 2.0, 11.5, 1.6, "Cats vs Dogs\nImage Classification", 54, True)
    text(s, 0.8, 4.0, 11, 0.6, f"A CNN with Keras / TensorFlow  |  {pc(m['test_accuracy'])} test accuracy", 22, False, ACC)
    text(s, 0.8, 5.6, 11, 0.8, [a.author, a.course], 18, False, MUTE)

    s = new_slide(prs, "Problem and dataset", "Explain why the task is a good fit: balanced, well-known, small model works.")
    text(s, 0.8, 1.6, 6.2, 4.5, ["Goal: decide whether a photo shows a cat or a dog.",
        "Dataset: Microsoft Cats vs Dogs (Kaggle), about 25,000 balanced images.",
        "Corrupt and empty files removed; all images converted to RGB.",
        "Split (seed 42): 90% train, 5% validation, 5% test."], 20)
    stat(s, 7.6, 1.8, 2.2, "~25k", "images"); stat(s, 10.1, 1.8, 2.2, "2", "classes")
    stat(s, 7.6, 3.5, 2.2, "150x150", "input size"); stat(s, 10.1, 3.5, 2.2, f"{m.get('test_images', '~1,250')}", "test images")

    s = new_slide(prs, "Model architecture", "Walk left to right. Rescaling to 0-1 is inside the model.")
    layers = ["Input\n150x150x3", "Rescale\n1/255", "Conv 32", "Conv 64", "MaxPool", "Conv 64", "Conv 128",
              "MaxPool", "Conv 128", "Conv 256", "Global\nAvgPool", "Dense\n1024", "Dense 2\nSoftmax"]
    for i, name in enumerate(layers):
        r, c = divmod(i, 7)
        b = box(s, 0.8 + c * 1.7, 1.9 + r * 1.7, 1.45, 1.1, SOFT if "Conv" in name else RGBColor(0xEE, 0xEC, 0xE4))
        text(s, 0.8 + c * 1.7, 1.9 + r * 1.7, 1.45, 1.1, name.split("\n"), 14, True, INK, PP_ALIGN.CENTER, MSO_ANCHOR.MIDDLE)
    text(s, 0.8, 5.5, 11.5, 0.8, f"All convolutions 3x3 + ReLU  |  {m['parameters'] / 1e6:.2f} million parameters", 18, False, MUTE)

    s = new_slide(prs, "Training setup", "Mention the best checkpoint was kept by validation accuracy.")
    text(s, 0.8, 1.6, 6, 4.5, ["Framework: Keras / TensorFlow", "Optimizer: RMSprop, learning rate 0.001",
        "Loss: sparse categorical cross-entropy", f"Epochs: {m['epochs']}",
        f"Batch size: {m.get('batch_size', 64)}", "Best checkpoint kept by validation accuracy"], 20)
    if "best_val_accuracy" in m: stat(s, 8.0, 2.2, 3.6, pc(m["best_val_accuracy"]), "best validation accuracy")
    pic(s, res / "training_curves.png", 6.6, 4.0, w=6.0)

    s = new_slide(prs, "Results on the test set", "Point out the diagonal of the confusion matrix and which class is confused more.")
    for i, (k, l) in enumerate([("test_accuracy", "Accuracy"), ("precision", "Precision"), ("recall", "Recall"), ("f1_score", "F1 score")]):
        stat(s, 0.8 + (i % 2) * 2.9, 1.7 + (i // 2) * 1.7, 2.6, pc(m[k]), l)
    text(s, 0.8, 5.2, 5.5, 1.0, "Precision, recall and F1 are macro-averaged over both classes.", 14, False, MUTE)
    pic(s, res / "confusion_matrix.png", 7.0, 1.5, h=4.8)

    sj = json.loads((ROOT.parent / "lib" / "project-data.json").read_text()).get("predictions", [])
    if sj:
        s = new_slide(prs, "Prediction examples", "Show a correct prediction and, if there is one, an error and why it may happen.")
        for i, pr in enumerate(sj[:6]):
            x, y = 0.8 + (i % 3) * 4.0, 1.6 + (i // 3) * 2.8
            pic(s, ROOT.parent / "public" / pr["image"].lstrip("/"), x, y, h=2.0)
            ok = pr["label"] == pr["predicted"]
            text(s, x + 2.1, y + 0.4, 1.8, 1.4, [f"True: {pr['label']}", f"Pred: {pr['predicted']}", f"{pr['confidence'] * 100:.0f}%"],
                 14, True, RGBColor(0x15, 0x80, 0x3D) if ok else RGBColor(0xB9, 0x1C, 0x1C))

    s = new_slide(prs, "Conclusion", "Finish with improvements and thank the audience.")
    text(s, 0.8, 1.6, 11.5, 2.6, [f"A small CNN reaches {pc(m['test_accuracy'])} accuracy on unseen images.",
        "Next steps: data augmentation, batch normalization, longer training, or transfer learning (MobileNetV2)."], 20)
    text(s, 0.8, 4.4, 11.5, 1.8, [f"GitHub: {links['github']}", f"Report: {links['report']}", f"Video: {links['youtube']}"], 16, False, ACC)

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    prs.save(a.out)
    print(f"Saved {a.out} ({len(prs.slides)} slides)")


if __name__ == "__main__":
    main()
