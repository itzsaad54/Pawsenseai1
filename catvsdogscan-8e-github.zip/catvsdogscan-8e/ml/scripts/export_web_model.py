"""Export model.keras to ../public/model/ so the website can run LIVE predictions in the browser.

    python scripts/export_web_model.py
Writes public/model/weights.bin (float32, ~3.4 MB) and public/model/manifest.json.
The architecture is rebuilt in TensorFlow.js (lib/classifier.ts), so no converter is needed.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import tensorflow as tf

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT.parent


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", default=str(ROOT / "model.keras"))
    a = p.parse_args()
    model = tf.keras.models.load_model(a.weights)

    out = SITE / "public" / "model"
    out.mkdir(parents=True, exist_ok=True)
    shapes, chunks = [], []
    for layer in model.layers:
        for w in layer.get_weights():          # kernel, bias (same order as tf.js)
            shapes.append(list(w.shape))
            chunks.append(np.asarray(w, dtype="<f4").ravel())
    (out / "weights.bin").write_bytes(np.concatenate(chunks).tobytes())
    (out / "manifest.json").write_text(json.dumps({
        "shapes": shapes,
        "input": [150, 150, 3],
        "classes": ["Cat", "Dog"],
        "parameters": int(model.count_params()),
    }))
    print(f"Exported {len(shapes)} tensors -> {out}. Expect 16 (8 layers x kernel+bias).")


if __name__ == "__main__":
    main()
