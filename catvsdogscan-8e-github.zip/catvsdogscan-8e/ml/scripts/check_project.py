"""Pre-submission checklist. Run from ml/:  python scripts/check_project.py"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT.parent
ok = True


def check(cond, msg):
    global ok
    print(("[ OK ] " if cond else "[FAIL] ") + msg)
    ok &= bool(cond)


for f in ["train.py", "model.py", "test.py", "data.py", "model.keras", "requirements.txt", "README.md", "docs/REPORT.md"]:
    check((ROOT / f).is_file(), f"ml/{f} exists")

check((SITE / "app/page.tsx").is_file(), "website (app/page.tsx) exists")
check((SITE / "public/model/weights.bin").is_file(), "public/model/weights.bin exists (live demo enabled)")
check((ROOT / "model.keras").is_file() and (ROOT / "model.keras").stat().st_size < 100e6,
      "model.keras is under 100 MB (no Git LFS needed)")

mp = ROOT / "results/metrics.json"
check(mp.is_file() and "f1_score" in json.loads(mp.read_text()),
      "results/metrics.json has real measured metrics (run scripts/evaluate.py)")

readme = (ROOT / "README.md").read_text()
check("python test.py" in readme, "README explains how to load/test the model")

report = (ROOT / "docs/REPORT.md").read_text()
check("[FILL" not in report, "docs/REPORT.md has no [FILL] placeholders")

site = json.loads((SITE / "lib/project-data.json").read_text())
check(site.get("metrics") is not None, "lib/project-data.json has metrics (run scripts/export_demo.py)")
check(site["author"]["name"] != "Your Name", "author name is filled in")
for k, v in site["links"].items():
    valid = (v.startswith("http") or v.startswith("/")) and not re.search(r"YOUR_|VIDEO_ID", v)
    check(valid, f"site link '{k}' is filled in")

bad = [str(p) for p in ROOT.glob("*.py") if re.search(r"[A-Za-z]:[\\/]|/Users/|/home/", p.read_text())]
check(not bad, "no absolute paths in code" + (f" ({bad})" if bad else ""))

if (ROOT / "model.keras").is_file():
    try:
        import tensorflow as tf
        shape = tf.keras.models.load_model(ROOT / "model.keras").input_shape
        check(tuple(shape[1:]) == (150, 150, 3), f"model input shape is {shape} (report says 150x150x3)")
    except Exception as e:
        check(False, f"model.keras loads ({e})")

print("\nALL GOOD" if ok else "\nFix the [FAIL] items above.")
sys.exit(0 if ok else 1)
