"""After training: fill the website with real metrics + prediction examples.

    python scripts/export_demo.py --weights model.keras --data_dir data/test --n 8

Updates ../lib/project-data.json (read by the Next.js site at build time) and copies
sample images + plots into ../public/.
"""
import argparse
import json
import random
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT.parent
sys.path.insert(0, str(ROOT))

import numpy as np
import tensorflow as tf
from PIL import Image

from data import load_image, load_split
from model import CLASS_NAMES

SITE_JSON = SITE / "lib" / "project-data.json"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", default=str(ROOT / "model.keras"))
    p.add_argument("--data_dir", default=str(ROOT / "data" / "test"))
    p.add_argument("--n", type=int, default=8, help="examples (half cats, half dogs)")
    p.add_argument("--seed", type=int, default=7)
    a = p.parse_args()

    model = tf.keras.models.load_model(a.weights)
    rng = random.Random(a.seed)
    samples_dir = SITE / "public" / "samples"
    samples_dir.mkdir(parents=True, exist_ok=True)
    for old in samples_dir.glob("*.jpg"):
        old.unlink()

    preds = []
    for folder, label in (("cats", "Cat"), ("dogs", "Dog")):
        files = sorted((Path(a.data_dir) / folder).glob("*.jpg"))
        for i, f in enumerate(rng.sample(files, a.n // 2)):
            probs = model.predict(load_image(f), verbose=0)[0]
            k = int(np.argmax(probs))
            name = f"{folder}_{i}.jpg"
            Image.open(f).convert("RGB").resize((300, 300)).save(samples_dir / name, quality=85)
            preds.append({"image": f"/samples/{name}", "label": label,
                          "predicted": CLASS_NAMES[k], "confidence": round(float(probs[k]), 4)})

    cm = [[0, 0], [0, 0]]   # rows = true, cols = predicted
    for x, y in load_split(a.data_dir, 64):
        for t, q in zip(y.numpy(), model.predict(x, verbose=0).argmax(1)):
            cm[int(t)][int(q)] += 1

    site = json.loads(SITE_JSON.read_text())
    site["confusion"] = {"classes": CLASS_NAMES, "matrix": cm}
    site["predictions"] = preds
    metrics = ROOT / "results" / "metrics.json"
    if metrics.exists():
        site["metrics"] = json.loads(metrics.read_text())

    results_dir = SITE / "public" / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    for png, key in (("training_curves.png", "trainingCurves"), ("confusion_matrix.png", "confusionImage")):
        src = ROOT / "results" / png
        if src.exists():
            shutil.copy(src, results_dir / png)
            site[key] = f"/results/{png}"

    SITE_JSON.write_text(json.dumps(site, indent=2) + "\n")
    print(f"Done: {len(preds)} examples + metrics written to lib/project-data.json. Commit and push.")


if __name__ == "__main__":
    main()
