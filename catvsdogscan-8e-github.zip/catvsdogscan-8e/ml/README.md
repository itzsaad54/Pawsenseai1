# Cats vs Dogs Image Classification

Binary image classifier (Cat / Dog) built with a small CNN in **Keras / TensorFlow**.

- **Live demo page:** _<Vercel link here>_
- **Report:** _<link here>_
- **Video:** _<YouTube link here>_

## Project at a glance

```
cats-vs-dogs-classifier/
|-- model.py            architecture (build_model)
|-- train.py            training -> model.keras + results/
|-- test.py             load / predict / evaluate
|-- data.py             clean + split + load data
|-- model.keras         trained model (created by train.py)
|-- requirements.txt
|-- scripts/
|   |-- evaluate.py     REAL metrics + confusion_matrix.png from the test set
|   |-- make_pptx.py    builds the presentation from results/metrics.json
|   |-- export_demo.py  fills the web page with metrics, confusion matrix, examples
|   |-- export_web_model.py  exports weights for the LIVE browser demo
|   `-- check_project.py  pre-submission checklist
|-- results/            metrics.json, training_curves.png
|-- web/                static demo page (deployed on Vercel)
`-- docs/               REPORT.md, VIDEO_SCRIPT.md, LINKEDIN_POST.md
```

## Workflow (start to finish)

1. `pip install -r requirements.txt`
2. `python train.py --raw_dir PetImages` -> creates `model.keras`
3. `python test.py` -> must print "Smoke test passed"
4. `python scripts/evaluate.py` -> real accuracy / precision / recall / F1 + confusion matrix
   `python scripts/make_pptx.py --author "Your Name"` -> `docs/Cats_vs_Dogs_Project.pptx`
   `python scripts/export_demo.py` -> fills `web/` with metrics, confusion matrix and predictions
   `python scripts/export_web_model.py` -> enables the live drag-and-drop demo (`web/model/`, ~3.4 MB)
5. Edit the 3 links in `web/data/site.js` and the report in `docs/REPORT.md`
6. `python scripts/check_project.py` -> every line must be `[ OK ]`
7. Push to GitHub, then on Vercel: import the repo, set **Root Directory = `web`**, Framework = Other, Deploy

## Repository files

| File | Purpose |
|---|---|
| `model.py` | Model architecture (`build_model()`) |
| `train.py` | Training script - produces `model.keras` |
| `test.py` | Loads `model.keras` and verifies / evaluates it |
| `data.py` | Dataset cleaning, splitting and loading helpers |
| `model.keras` | Trained model (architecture + weights, ~3 MB) |
| `requirements.txt` | Python dependencies |
| `results/` | Metrics and training curves |

## Quick check (how to load the model)

```bash
pip install -r requirements.txt
python test.py --weights model.keras
```

Classify an image: `python test.py --weights model.keras --image path/to/image.jpg`

Load it in your own code:

```python
import tensorflow as tf
model = tf.keras.models.load_model("model.keras")
# input: float32 array (N, 150, 150, 3), pixel values 0-255 (rescaling is inside the model)
# output: (N, 2) probabilities -> index 0 = Cat, index 1 = Dog
```

## Model

- **Input:** 150 x 150 x 3 RGB image
- **Architecture:** Rescaling -> 6 x Conv2D (32, 64, 64, 128, 128, 256) with 2 MaxPooling -> GlobalAveragePooling -> Dense(1024) -> Dense(2, softmax)
- **Loss / optimizer:** sparse categorical cross-entropy / RMSprop (lr = 0.001)
- **Parameters:** ~0.84 million

## Dataset

Microsoft Cats vs Dogs (about 25,000 images, balanced). It is not stored in this repo.
Download: https://www.kaggle.com/datasets/shaunthesheep/microsoft-catsvsdogs-dataset
and extract so that you have `PetImages/Cat` and `PetImages/Dog`.

Split used (seed 42): 90% train / 5% validation / 5% test. Corrupt images are removed automatically.

## Re-train

```bash
python train.py --raw_dir PetImages --epochs 10 --batch_size 64
```

This creates `model.keras`, `results/metrics.json` and `results/training_curves.png`.

## Results

| Epochs | Best val. accuracy | Test accuracy |
|---|---|---|
| 10 | _fill from results/metrics.json_ | _fill from results/metrics.json_ |
