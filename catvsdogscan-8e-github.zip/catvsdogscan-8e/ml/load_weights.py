"""Load weights/cats_vs_dogs.weights.h5 into the matching small CNN and check it.

Run from the repo root:
    python ml/load_weights.py
    python ml/load_weights.py --image public/examples/cat-1.jpg

The .h5 holds a 64x64 Sequential model (Conv32 > Pool > Conv64 > Pool > Flatten > Dense64 > Dense1 sigmoid).
It also tells you whether the weights were ever trained: freshly built Keras layers have all-zero biases.
"""
import argparse

import numpy as np
import tensorflow as tf
from PIL import Image

from model import SMALL_INPUT_SHAPE, build_small_model


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", default="weights/cats_vs_dogs.weights.h5")  # Keras 3 needs the *.weights.h5 suffix
    p.add_argument("--image", nargs="*", default=[])
    a = p.parse_args()

    model = build_small_model()
    model.load_weights(a.weights)
    print(f"Loaded {a.weights}: {model.count_params():,} parameters")

    zero_bias = all(np.allclose(l.get_weights()[1], 0) for l in model.layers if l.get_weights())
    if zero_bias:
        print("WARNING: every bias is exactly 0 -> these look like UNTRAINED starting weights. "
              "Train with the notebook / ml/train.py and save again with model.save_weights('....weights.h5').")

    for path in a.image:
        img = Image.open(path).convert("RGB").resize(SMALL_INPUT_SHAPE[:2])
        x = np.asarray(img, dtype="float32")[None] / 255.0
        prob_dog = float(model.predict(x, verbose=0)[0][0])
        print(f"{path}: {'Dog' if prob_dog >= 0.5 else 'Cat'} (P(dog)={prob_dog:.3f})")


if __name__ == "__main__":
    main()
