"""Check that the trained model loads and works.

    python test.py                          # smoke test (no data needed)
    python test.py --image samples/cat.jpg  # predict one or more images
    python test.py --data_dir data/test     # accuracy on a test folder (cats/, dogs/)
"""
import argparse
import sys

import numpy as np
import tensorflow as tf

from data import load_image, load_split
from model import CLASS_NAMES, INPUT_SHAPE


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", default="model.keras")
    p.add_argument("--image", nargs="*", help="image file(s) to classify")
    p.add_argument("--data_dir", help="folder with cats/ and dogs/ sub-folders")
    args = p.parse_args()

    model = tf.keras.models.load_model(args.weights)
    print(f"Loaded {args.weights} | input shape: {model.input_shape} | params: {model.count_params():,}")
    assert tuple(model.input_shape[1:]) == INPUT_SHAPE, "Input shape mismatch!"

    if args.image:
        for path in args.image:
            probs = model.predict(load_image(path), verbose=0)[0]
            k = int(np.argmax(probs))
            print(f"{path}: {CLASS_NAMES[k]} ({probs[k]*100:.1f}%)")
    elif args.data_dir:
        loss, acc = model.evaluate(load_split(args.data_dir))
        print(f"Accuracy: {acc*100:.2f}%  Loss: {loss:.4f}")
    else:
        dummy = np.random.randint(0, 256, size=(2,) + INPUT_SHAPE).astype("float32")
        out = model.predict(dummy, verbose=0)
        assert out.shape == (2, 2) and np.allclose(out.sum(axis=1), 1, atol=1e-4)
        print("Smoke test passed: model loads and outputs valid probabilities.")


if __name__ == "__main__":
    sys.exit(main())
