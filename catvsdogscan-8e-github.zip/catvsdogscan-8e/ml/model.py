"""Model architecture for Cats vs Dogs classification (Keras)."""
import tensorflow as tf
from tensorflow.keras import layers, Model

IMG_SIZE = (150, 150)          # (height, width) - must match the report
INPUT_SHAPE = (150, 150, 3)
CLASS_NAMES = ["Cat", "Dog"]   # index 0 = Cat, index 1 = Dog


def build_model() -> Model:
    """Simple 6-layer CNN with global average pooling.

    Input : RGB image, pixel values 0-255 (rescaling to 0-1 is done INSIDE the
            model, so no manual preprocessing is needed at test time).
    Output: softmax over 2 classes [Cat, Dog].
    """
    inputs = layers.Input(shape=INPUT_SHAPE, name="image")
    x = layers.Rescaling(1.0 / 255, name="rescale")(inputs)

    x = layers.Conv2D(32, (3, 3), activation="relu")(x)
    x = layers.Conv2D(64, (3, 3), activation="relu")(x)
    x = layers.MaxPooling2D(2, 2)(x)

    x = layers.Conv2D(64, (3, 3), activation="relu")(x)
    x = layers.Conv2D(128, (3, 3), activation="relu")(x)
    x = layers.MaxPooling2D(2, 2)(x)

    x = layers.Conv2D(128, (3, 3), activation="relu")(x)
    x = layers.Conv2D(256, (3, 3), activation="relu")(x)
    x = layers.GlobalAveragePooling2D()(x)

    x = layers.Dense(1024, activation="relu")(x)
    outputs = layers.Dense(2, activation="softmax", name="predictions")(x)

    model = Model(inputs, outputs, name="cats_vs_dogs_cnn")
    model.compile(
        optimizer=tf.keras.optimizers.RMSprop(learning_rate=0.001),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


# ---------------------------------------------------------------------------
# Architecture that matches weights/cats_vs_dogs.weights.h5 (found by reading the
# tensor shapes in the file): 64x64 input, 2 conv blocks, Dense(64), 1 sigmoid output.
# NOTE: in that file the weights are still the random starting values (all biases
# are exactly 0), so the model has NOT been trained yet. See weights/README.md.
# ---------------------------------------------------------------------------
SMALL_INPUT_SHAPE = (64, 64, 3)


def build_small_model() -> Model:
    """Small CNN whose layer shapes match weights/cats_vs_dogs.weights.h5 (822,337 parameters)."""
    model = tf.keras.Sequential([
        layers.Input(shape=SMALL_INPUT_SHAPE),
        layers.Conv2D(32, (3, 3), activation="relu"),
        layers.MaxPooling2D(2, 2),
        layers.Conv2D(64, (3, 3), activation="relu"),
        layers.MaxPooling2D(2, 2),
        layers.Flatten(),
        layers.Dense(64, activation="relu"),
        layers.Dense(1, activation="sigmoid"),   # probability of "Dog"
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


if __name__ == "__main__":
    build_model().summary()
