# Cats vs Dogs Image Classification with a CNN

**Author:** [FILL: your name, roll no.] | **Course:** Deep Learning

## 1. Introduction
Image classification is a core computer-vision task. This project builds a convolutional neural network (CNN)
that classifies a photo as **Cat** or **Dog**. It was chosen because the task is well defined, the data is balanced,
and a small model can reach good accuracy without special hardware.

## 2. Method
**Dataset.** Microsoft Cats vs Dogs (Kaggle), about 25,000 images, 12,500 per class. Corrupt/empty files are removed
(about 24,998 valid images remain). Split with seed 42: 90% train (~22,500), 5% validation (~1,250), 5% test (~1,250).

**Preprocessing.** Images are converted to RGB and resized to **150 x 150**. Pixel values are scaled to 0-1 by a
`Rescaling` layer inside the model.

**Architecture.** Rescaling -> Conv(32) -> Conv(64) -> MaxPool -> Conv(64) -> Conv(128) -> MaxPool -> Conv(128) ->
Conv(256) -> GlobalAveragePooling -> Dense(1024, ReLU) -> Dense(2, Softmax). All convolutions use 3x3 kernels and ReLU.
Total parameters: [FILL from results/metrics.json] (about 0.84 million).

**Training.** Framework: Keras / TensorFlow. Optimizer RMSprop (learning rate 0.001), loss sparse categorical
cross-entropy, batch size [FILL: 64], epochs [FILL: 10]. The checkpoint with the best validation accuracy is saved
as `ml/model.keras`.

## 3. Results
| Metric | Value |
|---|---|
| Best validation accuracy | [FILL] |
| Test accuracy | [FILL] |
| Test loss | [FILL] |
| Precision (macro) | [FILL] |
| Recall (macro) | [FILL] |
| F1 score (macro) | [FILL] |

Confusion matrix: see `results/confusion_matrix.png`. All values come from `results/metrics.json` (created by `ml/scripts/evaluate.py`) - never type them by hand.

Training curves: see `results/training_curves.png`. [FILL: 2-3 sentences - did training and validation accuracy rise
together? any overfitting? which classes were confused?]

## 4. Conclusion
[FILL: one paragraph.] Possible improvements: data augmentation with longer training, batch normalization, dropout, or
transfer learning (e.g. MobileNetV2), which usually exceeds 95% on this dataset.

## 5. Links
GitHub: https://github.com/itzsaad54/catvsdogscan-8e | Demo: [FILL: Vercel link] | Video: https://youtube.com/shorts/Sfz5Aua0-T8
