# 3-5 minute video script (screen-record slides + page, upload to YouTube as Unlisted)

| Time | Show | Say |
|---|---|---|
| 0:00 | Title slide | Name, project title, one sentence on the goal: classify cat vs dog. |
| 0:25 | Dataset slide / web page "Dataset" | Microsoft Cats vs Dogs, ~25k images, balanced, 90/5/5 split, 150x150 input. |
| 1:00 | Architecture slide / page diagram | Walk through conv blocks, pooling, dense layer, softmax output. |
| 2:00 | GitHub repo | Show ml/train.py, ml/model.py, weights/, README. Run `python ml/test.py` in terminal. |
| 2:45 | Vercel page, "Try it live" | Drag a cat photo and a dog photo into the demo and show the probabilities. This is your wow moment. |
| 3:00 | Results slide / page | Test accuracy, training curves, a few correct and wrong predictions. |
| 4:00 | Conclusion slide | What worked, limits, next step (transfer learning). Thank you. |

Tips: record with OBS or Loom, 1080p, check audio first, keep each slide under a minute.

## Suggested slides (7)
1 Title, 2 Problem, 3 Dataset, 4 Architecture, 5 Training setup, 6 Results, 7 Conclusion + links.
