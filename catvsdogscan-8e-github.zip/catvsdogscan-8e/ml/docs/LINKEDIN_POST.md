I just completed my Deep Learning project: **Cat vs Dog image classification**.

I trained a CNN in Keras/TensorFlow on ~25,000 images and reached **[X]% test accuracy**.
The code and trained model are on GitHub, and there is a live demo page with results and architecture.

GitHub: https://github.com/itzsaad54/catvsdogscan-8e
Demo: [link]
Video walkthrough: https://youtube.com/shorts/Sfz5Aua0-T8

What I learned: data cleaning matters as much as the model, and a clean train/validation/test split keeps results honest.

#DeepLearning #MachineLearning #TensorFlow #ComputerVision #Python
