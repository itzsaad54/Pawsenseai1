import type * as TF from '@tensorflow/tfjs'

type Manifest = {
  shapes: number[][]
  input: [number, number, number]
  classes: string[]
  parameters: number
}

export type Classifier = {
  classes: string[]
  parameters: number
  predict: (image: HTMLImageElement) => Promise<number[]>
}

export class ModelUnavailableError extends Error {}

function buildArchitecture(tf: typeof TF) {
  const conv = (filters: number, inputShape?: number[]) =>
    tf.layers.conv2d({ filters, kernelSize: 3, activation: 'relu', ...(inputShape ? { inputShape } : {}) })

  return tf.sequential({
    layers: [
      conv(32, [150, 150, 3]),
      conv(64),
      tf.layers.maxPooling2d({ poolSize: 2, strides: 2 }),
      conv(64),
      conv(128),
      tf.layers.maxPooling2d({ poolSize: 2, strides: 2 }),
      conv(128),
      conv(256),
      tf.layers.globalAveragePooling2d({}),
      tf.layers.dense({ units: 1024, activation: 'relu' }),
      tf.layers.dense({ units: 2, activation: 'softmax' }),
    ],
  })
}

export async function loadClassifier(): Promise<Classifier> {
  const manifestRes = await fetch('/model/manifest.json')
  if (!manifestRes.ok) throw new ModelUnavailableError('Model weights have not been exported yet.')
  const manifest = (await manifestRes.json()) as Manifest

  const [tf, weightsRes] = await Promise.all([import('@tensorflow/tfjs'), fetch('/model/weights.bin')])
  if (!weightsRes.ok) throw new ModelUnavailableError('weights.bin is missing.')
  const buffer = new Float32Array(await weightsRes.arrayBuffer())

  await tf.ready()
  const model = buildArchitecture(tf)

  let offset = 0
  const tensors = manifest.shapes.map((shape) => {
    const size = shape.reduce((a, b) => a * b, 1)
    const t = tf.tensor(buffer.subarray(offset, offset + size), shape)
    offset += size
    return t
  })
  model.setWeights(tensors)
  tensors.forEach((t) => t.dispose())

  const [h, w] = manifest.input

  return {
    classes: manifest.classes,
    parameters: manifest.parameters,
    async predict(image) {
      const output = tf.tidy(() => {
        const pixels = tf.browser.fromPixels(image).toFloat()
        const resized = tf.image.resizeBilinear(pixels, [h, w])
        return model.predict(resized.div(255).expandDims(0)) as TF.Tensor
      })
      const probs = Array.from(await output.data())
      output.dispose()
      return probs
    },
  }
}
