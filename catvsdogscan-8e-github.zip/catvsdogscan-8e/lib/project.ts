import data from './project-data.json'

export type Metrics = {
  test_accuracy: number
  precision?: number
  recall?: number
  f1_score?: number
  best_val_accuracy?: number
  test_loss?: number
  epochs?: number
  batch_size?: number
  parameters?: number
  test_images?: number
}

export type Prediction = {
  image: string
  label: string
  predicted: string
  confidence: number
}

export type ProjectData = {
  author: { name: string; rollNo: string; course: string; instructor?: string; classTerm?: string }
  links: {
    liveApp?: string
    github: string
    report: string
    youtube: string
    presentation: string
    linkedin: string
    dataset: string
  }
  metrics: Metrics | null
  confusion: { classes: string[]; matrix: number[][] } | null
  predictions: Prediction[]
  trainingCurves: string | null
  confusionImage: string | null
}

export const project = data as ProjectData

export function isPlaceholder(url: string) {
  return !url || /YOUR_|VIDEO_ID/.test(url)
}

export function youtubeId(url: string) {
  if (isPlaceholder(url)) return null
  const match = url.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([\w-]{11})/)
  return match ? match[1] : null
}

export function repoFileUrl(path: string) {
  return `${project.links.github.replace(/\/$/, '')}/blob/main/${path}`
}

export function repoRawUrl(path: string) {
  return `${project.links.github.replace(/\/$/, '')}/raw/main/${path}`
}

export const ARCHITECTURE = [
  { layer: 'Input', output: '150 × 150 × 3', params: 0, note: 'RGB image, pixels 0–255' },
  { layer: 'Rescaling (1/255)', output: '150 × 150 × 3', params: 0, note: 'Normalisation inside the model' },
  { layer: 'Conv2D 32, 3×3, ReLU', output: '148 × 148 × 32', params: 896, note: '' },
  { layer: 'Conv2D 64, 3×3, ReLU', output: '146 × 146 × 64', params: 18496, note: '' },
  { layer: 'MaxPooling 2×2', output: '73 × 73 × 64', params: 0, note: '' },
  { layer: 'Conv2D 64, 3×3, ReLU', output: '71 × 71 × 64', params: 36928, note: '' },
  { layer: 'Conv2D 128, 3×3, ReLU', output: '69 × 69 × 128', params: 73856, note: '' },
  { layer: 'MaxPooling 2×2', output: '34 × 34 × 128', params: 0, note: '' },
  { layer: 'Conv2D 128, 3×3, ReLU', output: '32 × 32 × 128', params: 147584, note: '' },
  { layer: 'Conv2D 256, 3×3, ReLU', output: '30 × 30 × 256', params: 295168, note: '' },
  { layer: 'Global Average Pooling', output: '256', params: 0, note: '' },
  { layer: 'Dense 1024, ReLU', output: '1024', params: 263168, note: '' },
  { layer: 'Dense 2, Softmax', output: '2 (Cat, Dog)', params: 2050, note: 'Class probabilities' },
] as const

export const TOTAL_PARAMS = ARCHITECTURE.reduce((sum, l) => sum + l.params, 0)
