import type { LinkItem } from '@/components/link-card'
import { isPlaceholder, project, repoFileUrl } from '@/lib/project'

const { links } = project
const repoReady = !isPlaceholder(links.github)

function link(item: Omit<LinkItem, 'ready'>, ready = !isPlaceholder(item.href)): LinkItem {
  return { ...item, ready }
}

export const CORE_LINKS: LinkItem[] = [
  link(
    {
      tag: 'Required',
      title: 'Live Web App',
      description: 'Upload a cat or dog photo and get a prediction with confidence, computed right in your browser.',
      href: links.liveApp || '#demo',
      display: links.liveApp || 'This page · #demo',
    },
    true,
  ),
  link({
    tag: 'Required',
    title: 'GitHub Repository',
    description: 'Source code, training and evaluation scripts, model weights, report and presentation.',
    href: links.github,
  }),
  link({
    tag: 'Required',
    title: 'YouTube Presentation Video',
    description: 'Slide presentation with a voiceover and a live walkthrough of the demo.',
    href: links.youtube,
  }),
  link({
    tag: 'Required',
    title: 'LinkedIn Project Post',
    description: 'Public post announcing the project with the repository and demo links.',
    href: links.linkedin,
  }),
]

export const RESOURCE_LINKS: LinkItem[] = [
  link({
    tag: 'Dataset',
    title: 'Microsoft Cats vs Dogs (Kaggle)',
    description: 'Source of the images: 25,000 labelled photos, 12,500 cats and 12,500 dogs.',
    href: links.dataset,
  }),
  link(
    {
      tag: 'Document',
      title: 'Project Report',
      description: 'Full technical report: problem, dataset, architecture, training, results and limitations.',
      href: links.report,
    },
    true,
  ),
  link(
    {
      tag: 'Document',
      title: 'Presentation Slides (PPTX)',
      description: 'Slide deck covering the project from problem statement to future work.',
      href: links.presentation,
    },
    repoReady,
  ),
  link(
    {
      tag: 'Code',
      title: 'Training Script',
      description: 'Data cleaning, 90/5/5 split, model definition and the training loop with checkpointing.',
      href: repoFileUrl('ml/train.py'),
    },
    repoReady,
  ),
  link(
    {
      tag: 'Code',
      title: 'Evaluation Script',
      description: 'Loads the saved model and reports accuracy, precision, recall, F1 and the confusion matrix.',
      href: repoFileUrl('ml/scripts/evaluate.py'),
    },
    repoReady,
  ),
  link(
    {
      tag: 'Notebook',
      title: 'Training Notebook (.ipynb)',
      description: 'Kaggle notebook: data split, CNN training, evaluation and class activation maps.',
      href: repoFileUrl('notebooks/cats-vs-dogs-classification.ipynb'),
    },
    repoReady,
  ),
  link(
    {
      tag: 'Weights',
      title: 'Model Weights (.h5)',
      description: 'Keras weights file in weights/. Read weights/README.md before using it.',
      href: repoFileUrl('weights/cats_vs_dogs.weights.h5'),
    },
    repoReady,
  ),
]

export const ALL_LINKS = [...CORE_LINKS, ...RESOURCE_LINKS]
