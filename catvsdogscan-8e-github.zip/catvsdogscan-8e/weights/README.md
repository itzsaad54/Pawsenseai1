# weights/

## cats_vs_dogs.weights.h5 (your uploaded file, renamed)
Renamed from `cats_vs_dogs_weights.weights_3.h5` because Keras 3 only accepts weight files ending in `.weights.h5`.

What is inside (read straight from the file):

| Layer | Weight shape |
|---|---|
| Conv2D 32, 3×3 | (3, 3, 3, 32) + bias 32 |
| Conv2D 64, 3×3 | (3, 3, 32, 64) + bias 64 |
| Dense 64 | (12544, 64) + bias 64 |
| Dense 1 (sigmoid) | (64, 1) + bias 1 |

That is a 64×64 Sequential model (Conv > Pool > Conv > Pool > Flatten > Dense > Dense), 822,337 parameters. It is built by `build_small_model()` in `ml/model.py`.

**Problem: it is untrained.** Every bias is exactly 0 and the kernels have the spread of Keras' random initialiser (e.g. the Dense(12544, 64) kernel has std 0.0126, which is sqrt(2 / (12544 + 64))). A numpy forward pass on the four example photos gave P(dog) of 0.48, 0.49, 0.50 and 0.51, i.e. coin flips. It was most likely saved before `model.fit()` finished or ran.

Check it yourself: `python ml/load_weights.py --image public/examples/cat-1.jpg`

## What to put here
Train, then save the trained weights in this folder:
- `cd ml && python train.py --raw_dir PetImages` → `ml/model.keras` (the 150×150 model the website uses), or
- in your notebook, after `model.fit(...)`: `model.save('cats_vs_dogs.keras')` and `model.save_weights('cats_vs_dogs.weights.h5')`, download from Kaggle "Output", and replace the files here.
