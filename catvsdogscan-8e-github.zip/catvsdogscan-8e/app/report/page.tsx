import { readFile } from 'node:fs/promises'
import path from 'node:path'
import type { Metadata } from 'next'
import Markdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'

export const metadata: Metadata = {
  title: 'Project Report | Cats vs Dogs Classifier',
  description: 'Full report: problem statement, dataset, architecture, training details and results.',
}

export default async function ReportPage() {
  const report = await readFile(path.join(process.cwd(), 'ml/docs/REPORT.md'), 'utf8')

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-16 md:px-6">
        <article
          className="leading-relaxed text-foreground/90 [&_a]:text-primary [&_a]:underline [&_code]:rounded [&_code]:bg-muted [&_code]:px-1 [&_code]:font-mono [&_code]:text-sm [&_h1]:mb-6 [&_h1]:text-balance [&_h1]:text-4xl [&_h1]:font-semibold [&_h1]:tracking-tight [&_h1]:text-foreground [&_h2]:mb-3 [&_h2]:mt-12 [&_h2]:text-2xl [&_h2]:font-semibold [&_h2]:text-foreground [&_h3]:mb-2 [&_h3]:mt-8 [&_h3]:font-semibold [&_li]:mt-1 [&_ol]:my-4 [&_ol]:list-decimal [&_ol]:pl-6 [&_p]:my-4 [&_pre]:my-4 [&_pre]:overflow-x-auto [&_pre]:rounded-lg [&_pre]:bg-muted [&_pre]:p-4 [&_table]:my-6 [&_table]:w-full [&_table]:text-sm [&_td]:border-b [&_td]:px-3 [&_td]:py-2 [&_th]:border-b [&_th]:px-3 [&_th]:py-2 [&_th]:text-left [&_ul]:my-4 [&_ul]:list-disc [&_ul]:pl-6"
        >
          <Markdown remarkPlugins={[remarkGfm]}>{report}</Markdown>
        </article>
      </main>
      <SiteFooter />
    </>
  )
}
