import { Hero } from '@/components/hero'
import { LinksSections } from '@/components/links-sections'
import { DemoSection } from '@/components/demo-section'
import { GlanceSection } from '@/components/glance-section'
import { SiteFooter } from '@/components/site-footer'

export default function Home() {
  return (
    <div id="top">
      <Hero />
      <main>
        <LinksSections />
        <DemoSection />
        <GlanceSection />
      </main>
      <SiteFooter />
    </div>
  )
}
