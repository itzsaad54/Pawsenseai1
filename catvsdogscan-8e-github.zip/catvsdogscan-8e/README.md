# PawScan AI: Cats vs Dogs Classifier

A Keras CNN that classifies a photo as **Cat** or **Dog**, with a Next.js website and an in-browser TensorFlow.js demo.

| What | Link |
|---|---|
| GitHub | https://github.com/itzsaad54/catvsdogscan-8e |
| YouTube video | https://youtube.com/shorts/Sfz5Aua0-T8 |
| Live web app | _add your Vercel URL in `lib/project-data.json` → `links.liveApp`_ |
| LinkedIn post | _add in `lib/project-data.json` → `links.linkedin`_ |
| Dataset | https://www.kaggle.com/datasets/shaunthesheep/microsoft-catsvsdogs-dataset |

## Folders

```
app/ components/ lib/ public/   Next.js website (deployed on Vercel from the repo root)
ml/            Python: model.py, data.py, train.py, test.py, load_weights.py, scripts/, docs/
notebooks/     cats-vs-dogs-classification.ipynb (Kaggle training notebook)
weights/       cats_vs_dogs.weights.h5 + README.md
results/       notebook_results.json (metrics and plots from the scripts go here later)
class_names.json   requirements.txt   package.json
```

## Run the website
```bash
npm install
npm run dev        # http://localhost:3000
```
Vercel: import the repo, Framework Preset = Next.js, Root Directory = repo root. No settings to change.

## Train the model
```bash
pip install -r requirements.txt
cd ml
python train.py --raw_dir PetImages      # needs the Kaggle dataset extracted to ml/PetImages
python test.py
python scripts/evaluate.py && python scripts/export_demo.py && python scripts/export_web_model.py
```

## Weights: read this
`weights/cats_vs_dogs.weights.h5` is a smaller 64×64 network whose values are still the random starting weights (all biases are exactly 0), so it predicts about 50/50 for every image. See `weights/README.md`. The notebook model reached 86.4 % validation accuracy (`results/notebook_results.json`).
