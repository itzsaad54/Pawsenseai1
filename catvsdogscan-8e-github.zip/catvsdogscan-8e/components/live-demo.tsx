'use client'

import Image from 'next/image'
import { useCallback, useRef, useState } from 'react'
import useSWRImmutable from 'swr/immutable'
import { ImageUp, Loader2, TriangleAlert } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { ModelUnavailableError, loadClassifier } from '@/lib/classifier'

const EXAMPLES = [
  { src: '/examples/cat-1.jpg', alt: 'Orange tabby cat' },
  { src: '/examples/dog-1.jpg', alt: 'Golden retriever' },
  { src: '/examples/cat-2.jpg', alt: 'Grey cat' },
  { src: '/examples/dog-2.jpg', alt: 'Small dog' },
]

type Result = { probs: number[]; ms: number }

export function LiveDemo() {
  const { data: classifier, error, isLoading } = useSWRImmutable('classifier', loadClassifier, {
    shouldRetryOnError: false,
  })
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [result, setResult] = useState<Result | null>(null)
  const [running, setRunning] = useState(false)
  const [dragging, setDragging] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const selectImage = useCallback((url: string) => {
    setResult(null)
    setImageUrl((prev) => {
      if (prev?.startsWith('blob:')) URL.revokeObjectURL(prev)
      return url
    })
  }, [])

  const handleFile = (file?: File) => {
    if (file && file.type.startsWith('image/')) selectImage(URL.createObjectURL(file))
  }

  const runPrediction = async () => {
    if (!classifier || !imgRef.current) return
    setRunning(true)
    const start = performance.now()
    const probs = await classifier.predict(imgRef.current)
    setResult({ probs, ms: performance.now() - start })
    setRunning(false)
  }

  const unavailable = error instanceof ModelUnavailableError
  const classes = classifier?.classes ?? ['Cat', 'Dog']
  const winner = result ? (result.probs[0] >= result.probs[1] ? 0 : 1) : null

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-3">
        <div
          onDragOver={(e) => {
            e.preventDefault()
            setDragging(true)
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault()
            setDragging(false)
            handleFile(e.dataTransfer.files[0])
          }}
          className={cn(
            'relative flex aspect-[4/3] items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed bg-card transition-colors',
            dragging && 'border-primary bg-accent',
          )}
        >
          {imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element -- raw element is required for tf.browser.fromPixels
            <img
              ref={imgRef}
              src={imageUrl || '/placeholder.svg'}
              alt="Selected image to classify"
              crossOrigin="anonymous"
              onLoad={runPrediction}
              className="h-full w-full object-contain"
            />
          ) : (
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="flex flex-col items-center gap-3 p-8 text-center"
            >
              <span className="grid size-12 place-items-center rounded-full bg-accent text-accent-foreground">
                <ImageUp className="size-6" aria-hidden="true" />
              </span>
              <span className="font-medium">Drop an image here or click to upload</span>
              <span className="text-sm text-muted-foreground">JPG, PNG or WebP · processed locally, never uploaded</span>
            </button>
          )}
        </div>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="sr-only"
          aria-label="Upload an image"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <span className="text-sm text-muted-foreground">Or try an example:</span>
          {EXAMPLES.map((ex) => (
            <button
              key={ex.src}
              type="button"
              onClick={() => selectImage(ex.src)}
              aria-label={`Use example: ${ex.alt}`}
              className={cn(
                'overflow-hidden rounded-lg border-2 transition-all hover:border-primary',
                imageUrl === ex.src ? 'border-primary' : 'border-transparent',
              )}
            >
              <Image src={ex.src} alt="" width={56} height={56} className="size-14 object-cover" />
            </button>
          ))}
          {imageUrl && (
            <Button variant="ghost" size="lg" onClick={() => inputRef.current?.click()}>
              Upload another
            </Button>
          )}
        </div>
      </div>

      <div className="flex flex-col rounded-2xl border bg-card p-6 lg:col-span-2">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Prediction</h3>
          <ModelStatus loading={isLoading} ready={!!classifier} unavailable={unavailable} failed={!!error && !unavailable} />
        </div>

        {unavailable ? (
          <div className="mt-6 flex gap-3 rounded-xl bg-accent p-4 text-sm text-accent-foreground">
            <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            <p className="leading-relaxed">
              The trained weights haven&apos;t been exported for the browser yet. Run{' '}
              <code className="font-mono font-semibold">python scripts/export_web_model.py</code> after training to
              enable live predictions.
            </p>
          </div>
        ) : (
          <div className="mt-6 flex flex-1 flex-col" aria-live="polite">
            {result && winner !== null ? (
              <>
                <p className="text-sm text-muted-foreground">The model thinks this is a</p>
                <p className="mt-1 text-5xl font-semibold tracking-tight">{classes[winner]}</p>
                <p className="mt-2 font-mono text-sm text-muted-foreground">
                  {(result.probs[winner] * 100).toFixed(1)}% confident · {result.ms.toFixed(0)} ms
                </p>
                <div className="mt-8 flex flex-col gap-4">
                  {classes.map((c, i) => (
                    <ProbabilityBar key={c} label={c} value={result.probs[i]} highlight={i === winner} />
                  ))}
                </div>
              </>
            ) : (
              <p className="my-auto text-center text-sm text-muted-foreground">
                {running ? 'Running inference…' : 'Choose an image to see what the network predicts.'}
              </p>
            )}
          </div>
        )}

        <p className="mt-6 border-t pt-4 text-xs leading-relaxed text-muted-foreground">
          Images are resized to 150×150 and classified entirely in your browser using TensorFlow.js with the same
          weights as <code className="font-mono">model.keras</code>.
        </p>
      </div>
    </div>
  )
}

function ModelStatus({
  loading,
  ready,
  unavailable,
  failed,
}: {
  loading: boolean
  ready: boolean
  unavailable: boolean
  failed: boolean
}) {
  if (loading)
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
        <Loader2 className="size-3 animate-spin" aria-hidden="true" />
        Loading model
      </span>
    )
  const label = ready ? 'Model ready' : unavailable ? 'Weights not exported' : failed ? 'Failed to load' : ''
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
      <span
        aria-hidden="true"
        className={cn('size-1.5 rounded-full', ready ? 'bg-success' : failed ? 'bg-destructive' : 'bg-chart-4')}
      />
      {label}
    </span>
  )
}

function ProbabilityBar({ label, value, highlight }: { label: string; value: number; highlight: boolean }) {
  return (
    <div>
      <div className="mb-1.5 flex justify-between text-sm">
        <span className={cn(highlight && 'font-semibold')}>{label}</span>
        <span className="font-mono">{(value * 100).toFixed(1)}%</span>
      </div>
      <div
        className="h-2 overflow-hidden rounded-full bg-muted"
        role="meter"
        aria-label={`${label} probability`}
        aria-valuenow={Math.round(value * 100)}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div
          className={cn('h-full rounded-full transition-all duration-500', highlight ? 'bg-primary' : 'bg-chart-5/40')}
          style={{ width: `${value * 100}%` }}
        />
      </div>
    </div>
  )
}
