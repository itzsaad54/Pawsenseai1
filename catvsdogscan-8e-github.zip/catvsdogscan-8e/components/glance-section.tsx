import Image from 'next/image'
import { ConfusionMatrix } from '@/components/results-section'
import { ARCHITECTURE, TOTAL_PARAMS, project } from '@/lib/project'
import { cn } from '@/lib/utils'

const pct = (v?: number) => (typeof v === 'number' ? `${(v * 100).toFixed(2)}%` : 'Pending')

const CODE_STRUCTURE = [
  ['ml/data.py', 'Cleans corrupt files, 90/5/5 split, tf.data loaders'],
  ['ml/model.py', 'CNN definition (Rescaling, 6 conv layers, dense head)'],
  ['ml/train.py', 'Training loop, best-checkpoint saving, test evaluation'],
  ['ml/test.py', 'Predict a single image from the command line'],
  ['ml/scripts/', 'Evaluate, export demo data and web model, build slides'],
  ['app/, components/', 'This Next.js site and the in-browser TF.js demo'],
]

export function GlanceSection() {
  const { metrics, confusion, predictions, trainingCurves } = project
  const correct = metrics?.test_images ? Math.round(metrics.test_accuracy * metrics.test_images) : null

  return (
    <section aria-labelledby="glance" className="mx-auto max-w-6xl px-4 pt-14 md:px-6">
      <h2 id="glance" className="text-2xl font-bold">
        Project at a glance
      </h2>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <Card title="Dataset">
          <ul className="flex list-disc flex-col gap-2 pl-5 text-sm leading-relaxed text-muted-foreground">
            <li>Source: Microsoft Cats vs Dogs on Kaggle (25,000 images, 2 categories)</li>
            <li>Two balanced classes: Cat and Dog, 12,500 photos each; corrupt and empty files removed</li>
            <li>Split 90 / 5 / 5 into train, validation and test (seed 42)</li>
            <li>Resized to 150 × 150 RGB; pixel scaling to 0–1 happens inside the model</li>
          </ul>
        </Card>

        <Card title="Model and results">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs text-muted-foreground">
                  <th className="py-2 pr-3 font-semibold">Model</th>
                  <th className="py-2 pr-3 font-semibold">Approach</th>
                  <th className="py-2 text-right font-semibold">Test acc.</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="py-3 pr-3 font-bold">Custom 6-layer CNN</td>
                  <td className="py-3 pr-3 text-muted-foreground">
                    From scratch, ~{(TOTAL_PARAMS / 1e6).toFixed(2)} M params
                  </td>
                  <td className="py-3 text-right">
                    <span className="font-bold text-primary">{pct(metrics?.test_accuracy)}</span>
                    {correct !== null && (
                      <span className="block text-xs text-muted-foreground">
                        {correct} / {metrics?.test_images}
                      </span>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
            RMSprop (lr 0.001), sparse categorical cross-entropy, batch {metrics?.batch_size ?? 64},{' '}
            {metrics?.epochs ?? 10} epochs. The checkpoint with the best validation accuracy is kept.
          </p>
          <dl className="mt-4 grid grid-cols-3 gap-2 text-center">
            {[
              ['Precision', metrics?.precision],
              ['Recall', metrics?.recall],
              ['F1 score', metrics?.f1_score],
            ].map(([label, value]) => (
              <div key={label as string} className="rounded-lg border bg-background/60 p-3">
                <dt className="text-[11px] text-muted-foreground">{label}</dt>
                <dd className="mt-1 font-bold">{pct(value as number | undefined)}</dd>
              </div>
            ))}
          </dl>
        </Card>

        <Card title="Code structure">
          <table className="w-full text-sm">
            <tbody>
              {CODE_STRUCTURE.map(([file, desc]) => (
                <tr key={file} className="border-b last:border-0">
                  <td className="py-2 pr-4 align-top font-bold whitespace-nowrap text-primary">{file}</td>
                  <td className="py-2 text-muted-foreground">{desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card title="Confusion matrix (test split)">
          <ConfusionMatrix classes={confusion?.classes ?? ['Cat', 'Dog']} matrix={confusion?.matrix ?? null} />
          {!metrics && (
            <p className="mt-4 text-xs text-muted-foreground">
              Filled in after running <code className="text-foreground">python scripts/evaluate.py</code> and{' '}
              <code className="text-foreground">python scripts/export_demo.py</code>.
            </p>
          )}
        </Card>
      </div>

      <details className="group mt-4 rounded-2xl border bg-card p-5">
        <summary className="cursor-pointer text-sm font-bold marker:text-primary">
          Layer-by-layer architecture
        </summary>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-xs text-muted-foreground">
                <th className="py-2 pr-3 font-semibold">Layer</th>
                <th className="py-2 pr-3 font-semibold">Output shape</th>
                <th className="py-2 text-right font-semibold">Params</th>
              </tr>
            </thead>
            <tbody>
              {ARCHITECTURE.map((l) => (
                <tr key={l.layer + l.output} className="border-b last:border-0">
                  <td className="py-2 pr-3">{l.layer}</td>
                  <td className="py-2 pr-3 text-muted-foreground">{l.output}</td>
                  <td className="py-2 text-right tabular-nums">{l.params.toLocaleString()}</td>
                </tr>
              ))}
              <tr>
                <td className="pt-3 font-bold" colSpan={2}>
                  Total
                </td>
                <td className="pt-3 text-right font-bold text-primary tabular-nums">
                  {TOTAL_PARAMS.toLocaleString()}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </details>

      {(trainingCurves || predictions.length > 0) && (
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          {trainingCurves && (
            <Card title="Training curves">
              <Image
                src={trainingCurves}
                alt="Training and validation accuracy and loss per epoch"
                width={800}
                height={400}
                className="w-full rounded-lg"
              />
            </Card>
          )}
          {predictions.length > 0 && (
            <Card title="Sample test predictions">
              <ul className="grid grid-cols-3 gap-3">
                {predictions.slice(0, 6).map((p) => {
                  const ok = p.label === p.predicted
                  return (
                    <li key={p.image} className="overflow-hidden rounded-lg border">
                      <Image
                        src={p.image}
                        alt={`Test image of a ${p.label}`}
                        width={160}
                        height={160}
                        className="aspect-square w-full object-cover"
                      />
                      <p className={cn('p-2 text-[11px] font-bold', ok ? 'text-success' : 'text-destructive')}>
                        {ok ? 'Correct' : 'Wrong'}: {p.predicted} {(p.confidence * 100).toFixed(0)}%
                      </p>
                    </li>
                  )
                })}
              </ul>
            </Card>
          )}
        </div>
      )}
    </section>
  )
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card p-5 md:p-6">
      <h3 className="mb-4 text-base font-bold">{title}</h3>
      {children}
    </div>
  )
}
