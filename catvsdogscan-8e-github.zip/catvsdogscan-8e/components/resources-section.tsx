import Link from 'next/link'
import {
  ArrowUpRight,
  Code as Github,
  Database,
  FileText,
  Play as Youtube,
  Presentation,
  Share2 as Linkedin,
} from 'lucide-react'
import { SectionHeading } from '@/components/section-heading'
import { isPlaceholder, project, youtubeId } from '@/lib/project'

export function ResourcesSection() {
  const { links } = project
  const videoId = youtubeId(links.youtube)

  const resources = [
    { href: links.github, label: 'GitHub repository', desc: 'Source code, model weights and docs', Icon: Github },
    { href: links.report, label: 'Project report', desc: 'Problem, data, architecture and results', Icon: FileText },
    { href: links.presentation, label: 'Presentation', desc: 'Slide deck (PPTX)', Icon: Presentation },
    { href: links.youtube, label: 'Video walkthrough', desc: 'Voice-over of the slides on YouTube', Icon: Youtube },
    { href: links.linkedin, label: 'LinkedIn post', desc: 'Project announcement', Icon: Linkedin },
    { href: links.dataset, label: 'Dataset', desc: 'Microsoft Cats vs Dogs on Kaggle', Icon: Database },
  ]

  return (
    <section aria-labelledby="resources" className="scroll-mt-16 border-b bg-secondary/50">
      <div className="mx-auto max-w-6xl px-4 py-20 md:px-6">
        <SectionHeading
          id="resources"
          eyebrow="04 · Resources"
          title="Report, presentation & code"
          description="Everything needed to understand, reproduce and evaluate the project."
        />
        <div className="grid gap-6 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <div className="aspect-video overflow-hidden rounded-2xl border bg-card">
              {videoId ? (
                <iframe
                  src={`https://www.youtube-nocookie.com/embed/${videoId}`}
                  title="Project video walkthrough"
                  allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="h-full w-full"
                />
              ) : (
                <div className="grid h-full place-items-center p-6 text-center">
                  <div>
                    <Youtube className="mx-auto size-10 text-muted-foreground" aria-hidden="true" />
                    <p className="mt-3 font-medium">Video coming soon</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Add the YouTube link in <code className="font-mono">lib/project-data.json</code>
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
          <ul className="grid gap-3 sm:grid-cols-2 lg:col-span-2 lg:grid-cols-1">
            {resources.map(({ href, label, desc, Icon }) => {
              const pending = isPlaceholder(href)
              const internal = href.startsWith('/')
              const content = (
                <>
                  <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-accent text-accent-foreground">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-medium">{label}</span>
                    <span className="block truncate text-xs text-muted-foreground">
                      {pending ? 'Link not added yet' : desc}
                    </span>
                  </span>
                  <ArrowUpRight
                    className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                    aria-hidden="true"
                  />
                </>
              )
              const className =
                'group flex items-center gap-3 rounded-xl border bg-card p-3 transition-colors hover:border-primary'
              return (
                <li key={label}>
                  {internal ? (
                    <Link href={href} className={className}>
                      {content}
                    </Link>
                  ) : (
                    <a href={href} target="_blank" rel="noreferrer" className={className}>
                      {content}
                    </a>
                  )}
                </li>
              )
            })}
          </ul>
        </div>
      </div>
    </section>
  )
}
