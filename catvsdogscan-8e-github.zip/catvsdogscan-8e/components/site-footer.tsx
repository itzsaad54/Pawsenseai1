import { project } from '@/lib/project'

export function SiteFooter() {
  const { author } = project
  const details = [
    ['Author / Student', author.name],
    ['Roll number', author.rollNo],
    ['Class & term', author.classTerm],
    ['Course & instructor', [author.course, author.instructor].filter(Boolean).join(' · ')],
  ]

  return (
    <footer className="mt-16 border-t bg-card/50">
      <div className="mx-auto max-w-6xl px-4 py-12 md:px-6">
        <p className="text-lg font-bold">PawScan AI</p>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          A convolutional neural network for real-time cat vs dog image classification, from dataset to deployed demo.
        </p>
        <p className="mt-4 inline-block rounded-lg border bg-background/60 px-3 py-2 text-xs text-muted-foreground">
          Educational project · Predictions on images that contain neither a cat nor a dog are not meaningful.
        </p>

        <dl className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {details.map(([label, value]) => (
            <div key={label}>
              <dt className="text-[11px] font-semibold tracking-widest text-primary uppercase">{label}</dt>
              <dd className={value ? 'mt-1 text-sm' : 'mt-1 text-sm text-muted-foreground'}>{value || 'Not added'}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t pt-6 text-xs text-muted-foreground">
          <p>© 2026 PawScan AI · Deep Learning Semester Project</p>
          <a href="#top" className="hover:text-primary">
            Back to top ↑
          </a>
        </div>
      </div>
    </footer>
  )
}
