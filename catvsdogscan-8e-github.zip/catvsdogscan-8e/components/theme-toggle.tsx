'use client'

export function ThemeToggle() {
  const toggle = () => {
    const isDark = document.documentElement.classList.toggle('dark')
    try {
      localStorage.setItem('theme', isDark ? 'dark' : 'light')
    } catch {}
  }

  return (
    <button
      type="button"
      onClick={toggle}
      className="rounded-full border border-border bg-card/60 px-4 py-2 text-xs backdrop-blur transition-colors hover:border-primary"
    >
      Toggle theme
    </button>
  )
}
