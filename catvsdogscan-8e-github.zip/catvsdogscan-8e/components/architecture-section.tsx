import { SectionHeading } from '@/components/section-heading'
import { ARCHITECTURE, TOTAL_PARAMS } from '@/lib/project'

const TRAINING = [
  { label: 'Framework', value: 'TensorFlow / Keras' },
  { label: 'Optimizer', value: 'RMSprop, lr = 0.001' },
  { label: 'Loss', value: 'Sparse categorical cross-entropy' },
  { label: 'Epochs', value: '10' },
  { label: 'Batch size', value: '64' },
  { label: 'Checkpoint', value: 'Best validation accuracy' },
]

export function ArchitectureSection() {
  return (
    <section aria-labelledby="model" className="scroll-mt-16 border-b bg-secondary/50">
      <div className="mx-auto max-w-6xl px-4 py-20 md:px-6">
        <SectionHeading
          id="model"
          eyebrow="02 · Model"
          title="A compact CNN, trained from scratch"
          description="Three blocks of paired 3×3 convolutions extract increasingly abstract features. Global average pooling keeps the parameter count low before a dense classifier outputs class probabilities."
        />
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="overflow-x-auto rounded-2xl border bg-card lg:col-span-2">
            <table className="w-full text-sm">
              <caption className="sr-only">Layer-by-layer model architecture</caption>
              <thead>
                <tr className="border-b text-left text-xs text-muted-foreground">
                  <th scope="col" className="px-5 py-3 font-medium">
                    Layer
                  </th>
                  <th scope="col" className="px-5 py-3 font-medium">
                    Output shape
                  </th>
                  <th scope="col" className="px-5 py-3 text-right font-medium">
                    Params
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y font-mono">
                {ARCHITECTURE.map((l, i) => (
                  <tr key={i} className={l.layer.startsWith('Conv') ? '' : 'text-muted-foreground'}>
                    <td className="px-5 py-2.5">{l.layer}</td>
                    <td className="whitespace-nowrap px-5 py-2.5">{l.output}</td>
                    <td className="px-5 py-2.5 text-right">{l.params.toLocaleString('en-US')}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t font-mono font-semibold">
                  <td className="px-5 py-3" colSpan={2}>
                    Total trainable parameters
                  </td>
                  <td className="px-5 py-3 text-right">{TOTAL_PARAMS.toLocaleString('en-US')}</td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="flex flex-col gap-6">
            <div className="rounded-2xl border bg-card p-6">
              <h3 className="font-semibold">Training setup</h3>
              <dl className="mt-4 flex flex-col gap-3 text-sm">
                {TRAINING.map((t) => (
                  <div key={t.label} className="flex justify-between gap-4">
                    <dt className="text-muted-foreground">{t.label}</dt>
                    <dd className="text-right font-medium">{t.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="rounded-2xl border bg-card p-6">
              <h3 className="font-semibold">Load the weights</h3>
              <pre className="mt-4 overflow-x-auto rounded-lg bg-foreground p-4 font-mono text-xs leading-relaxed text-background">
                {`import tensorflow as tf
model = tf.keras.models.load_model(
    "model.keras")
# in : (N, 150, 150, 3), 0-255
# out: (N, 2) -> [Cat, Dog]`}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
