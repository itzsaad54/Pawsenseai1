import { CopyAllButton, LinkCard } from '@/components/link-card'
import { ALL_LINKS, CORE_LINKS, RESOURCE_LINKS } from '@/lib/links'

export function LinksSections() {
  const ready = ALL_LINKS.filter((l) => l.ready).length
  const total = ALL_LINKS.length
  const done = ready === total

  return (
    <>
      <section aria-labelledby="deliverables" className="mx-auto max-w-6xl scroll-mt-8 px-4 pt-10 md:px-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 id="deliverables" className="text-2xl font-bold">
              Core Deliverables
            </h2>
            <div className="mt-3 flex items-center gap-3">
              <div
                role="progressbar"
                aria-label="Project links ready"
                aria-valuenow={ready}
                aria-valuemin={0}
                aria-valuemax={total}
                className="h-2 w-36 overflow-hidden rounded-full bg-muted"
              >
                <div className="h-full rounded-full bg-primary" style={{ width: `${(ready / total) * 100}%` }} />
              </div>
              <p className="text-xs text-muted-foreground">
                {ready} of {total} links ready. {done ? 'All set.' : 'Add the rest in lib/project-data.json.'}
              </p>
            </div>
          </div>
          <CopyAllButton items={ALL_LINKS} />
        </div>
        <p className="mt-5 text-sm text-muted-foreground">
          Primary project components for review and testing. External cards open in a new tab.
        </p>
        <ul className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {CORE_LINKS.map((item) => (
            <li key={item.title}>
              <LinkCard item={item} />
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="resources" className="mx-auto max-w-6xl px-4 pt-14 md:px-6">
        <h2 id="resources" className="text-2xl font-bold">
          Project resources
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">Dataset, documents, code and model weights.</p>
        <ul className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {RESOURCE_LINKS.map((item) => (
            <li key={item.title}>
              <LinkCard item={item} />
            </li>
          ))}
        </ul>
      </section>
    </>
  )
}
