import Link from 'next/link'
import { project } from '@/lib/project'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/#demo', label: 'Demo' },
  { href: '/#dataset', label: 'Dataset' },
  { href: '/#model', label: 'Model' },
  { href: '/#results', label: 'Results' },
  { href: '/#resources', label: 'Resources' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-4 px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
          <span
            aria-hidden="true"
            className="grid size-7 place-items-center rounded-md bg-primary font-mono text-xs text-primary-foreground"
          >
            CD
          </span>
          <span>Cats vs Dogs</span>
        </Link>
        <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <a
          href={project.links.github}
          target="_blank"
          rel="noreferrer"
          className={cn(buttonVariants({ variant: 'outline', size: 'lg' }), 'px-3')}
        >
          GitHub
        </a>
      </div>
    </header>
  )
}
