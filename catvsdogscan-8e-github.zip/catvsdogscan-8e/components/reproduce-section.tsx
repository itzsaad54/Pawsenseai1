import { SectionHeading } from '@/components/section-heading'
import { repoFileUrl, repoRawUrl } from '@/lib/project'

const STEPS = [
  { cmd: 'pip install -r requirements.txt', desc: 'Install Python dependencies' },
  { cmd: 'python train.py --raw_dir PetImages', desc: 'Clean, split and train → model.keras' },
  { cmd: 'python test.py', desc: 'Smoke test the saved model' },
  { cmd: 'python scripts/evaluate.py', desc: 'Accuracy, precision, recall, F1, confusion matrix' },
  { cmd: 'python scripts/export_demo.py', desc: 'Publish results to this website' },
  { cmd: 'python scripts/export_web_model.py', desc: 'Enable the live in-browser demo' },
]

const FILES = [
  { path: 'ml/model.keras', desc: 'Trained model (architecture + weights)', raw: true },
  { path: 'ml/model.py', desc: 'Architecture definition' },
  { path: 'ml/train.py', desc: 'Training script' },
  { path: 'ml/test.py', desc: 'Load, predict & evaluate' },
  { path: 'ml/data.py', desc: 'Dataset cleaning & loading' },
  { path: 'ml/requirements.txt', desc: 'Dependencies' },
]

export function ReproduceSection() {
  return (
    <section aria-labelledby="code" className="scroll-mt-16">
      <div className="mx-auto max-w-6xl px-4 py-20 md:px-6">
        <SectionHeading
          id="code"
          eyebrow="05 · Code"
          title="Reproduce it yourself"
          description="The repository is structured so an automated evaluator can locate and load the weights directly."
        />
        <div className="grid gap-6 lg:grid-cols-2">
          <ol className="flex flex-col gap-3">
            {STEPS.map((s, i) => (
              <li key={s.cmd} className="flex gap-4 rounded-xl border bg-card p-4">
                <span className="font-mono text-sm text-primary">{String(i + 1).padStart(2, '0')}</span>
                <div className="min-w-0">
                  <code className="block overflow-x-auto whitespace-nowrap font-mono text-sm font-medium">{s.cmd}</code>
                  <p className="mt-1 text-xs text-muted-foreground">{s.desc}</p>
                </div>
              </li>
            ))}
          </ol>
          <div className="rounded-2xl border bg-card">
            <h3 className="border-b px-5 py-4 font-semibold">Repository files</h3>
            <ul className="divide-y">
              {FILES.map((f) => (
                <li key={f.path}>
                  <a
                    href={f.raw ? repoRawUrl(f.path) : repoFileUrl(f.path)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between gap-4 px-5 py-3 text-sm transition-colors hover:bg-muted"
                  >
                    <code className="font-mono font-medium">{f.path}</code>
                    <span className="text-right text-xs text-muted-foreground">
                      {f.raw ? 'Download weights' : f.desc}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
