import { ExternalLink } from 'lucide-react'
import { SectionHeading } from '@/components/section-heading'
import { project } from '@/lib/project'

const SPLITS = [
  { name: 'Train', pct: 90, images: '~22,450' },
  { name: 'Validation', pct: 5, images: '~1,245' },
  { name: 'Test', pct: 5, images: '~1,245' },
]

const FACTS = [
  { label: 'Source', value: 'Microsoft / Kaggle (secondary dataset)' },
  { label: 'Classes', value: 'Cat (0), Dog (1) — balanced' },
  { label: 'Raw images', value: '~12,500 per class' },
  { label: 'Cleaning', value: 'Corrupt & empty files removed, re-saved as RGB JPEG' },
  { label: 'Input size', value: '150 × 150 × 3, pixel values 0–255' },
  { label: 'Split seed', value: '42 (fully reproducible)' },
]

export function DatasetSection() {
  return (
    <section aria-labelledby="dataset" className="scroll-mt-16 border-b">
      <div className="mx-auto max-w-6xl px-4 py-20 md:px-6">
        <SectionHeading
          id="dataset"
          eyebrow="01 · Dataset"
          title="Microsoft Cats vs Dogs"
          description="A widely used benchmark of household pet photos with large variation in pose, lighting, background and breed — a realistic test for a model trained from scratch."
        />
        <div className="grid gap-6 md:grid-cols-2">
          <dl className="divide-y rounded-2xl border bg-card">
            {FACTS.map((f) => (
              <div key={f.label} className="grid grid-cols-3 gap-4 px-5 py-3.5 text-sm">
                <dt className="text-muted-foreground">{f.label}</dt>
                <dd className="col-span-2 font-medium">{f.value}</dd>
              </div>
            ))}
          </dl>

          <div className="flex flex-col rounded-2xl border bg-card p-6">
            <h3 className="font-semibold">Data split</h3>
            <div className="mt-6 flex h-10 overflow-hidden rounded-lg" aria-hidden="true">
              <div className="bg-primary" style={{ width: '90%' }} />
              <div className="bg-chart-2" style={{ width: '5%' }} />
              <div className="bg-chart-3" style={{ width: '5%' }} />
            </div>
            <ul className="mt-6 flex flex-col gap-3">
              {SPLITS.map((s, i) => (
                <li key={s.name} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <span
                      aria-hidden="true"
                      className={['bg-primary', 'bg-chart-2', 'bg-chart-3'][i] + ' size-2.5 rounded-sm'}
                    />
                    {s.name}
                  </span>
                  <span className="font-mono text-muted-foreground">
                    {s.pct}% · {s.images}
                  </span>
                </li>
              ))}
            </ul>
            <a
              href={project.links.dataset}
              target="_blank"
              rel="noreferrer"
              className="mt-auto inline-flex items-center gap-1.5 pt-6 text-sm font-medium text-primary hover:underline"
            >
              Download from Kaggle
              <ExternalLink className="size-3.5" aria-hidden="true" />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
