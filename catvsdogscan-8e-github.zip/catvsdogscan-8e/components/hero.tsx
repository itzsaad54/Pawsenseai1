import { ThemeToggle } from '@/components/theme-toggle'
import { TOTAL_PARAMS, project } from '@/lib/project'

export function Hero() {
  const acc = project.metrics?.test_accuracy
  const stats = [
    { value: typeof acc === 'number' ? `${(acc * 100).toFixed(2)}%` : 'Pending', label: 'CNN test accuracy' },
    { value: `${(TOTAL_PARAMS / 1e6).toFixed(2)}M`, label: 'Trainable parameters' },
    { value: '25,000', label: 'Labelled images' },
    { value: '2', label: 'Classes' },
  ]

  return (
    <header className="relative overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[30rem] bg-gradient-to-br from-background via-background to-accent/60"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 -right-32 size-[26rem] rounded-full bg-accent/70"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-56 right-16 size-[18rem] rounded-full bg-primary/15"
      />

      <div className="relative mx-auto max-w-6xl px-4 pt-10 pb-6 md:px-6">
        <div className="flex items-center justify-between gap-4">
          <p className="text-xs font-semibold tracking-[0.25em] text-primary uppercase">
            Deep Learning · Semester Project
          </p>
          <ThemeToggle />
        </div>

        <h1 className="mt-12 text-5xl font-extrabold tracking-tight text-balance md:text-7xl">PawScan AI</h1>
        <p className="mt-4 text-xl text-primary md:text-2xl">Cats vs Dogs Image Classifier</p>
        <p className="mt-5 max-w-2xl leading-relaxed text-pretty text-muted-foreground">
          A convolutional neural network trained from scratch that tells cats from dogs in milliseconds, running
          entirely in your browser. Every link for this project is collected on this page.
        </p>

        <div className="mt-8 flex flex-wrap gap-3">
          <a
            href="#demo"
            className="rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Try the live demo
          </a>
          <a
            href="#deliverables"
            className="rounded-xl border bg-card/60 px-5 py-3 text-sm font-bold backdrop-blur transition-colors hover:border-primary"
          >
            Jump to all links
          </a>
        </div>

        <dl className="mt-10 grid grid-cols-2 overflow-hidden rounded-2xl border bg-card shadow-lg md:grid-cols-4">
          {stats.map((s, i) => (
            <div
              key={s.label}
              className={`flex flex-col-reverse items-center gap-2 px-4 py-6 text-center ${i % 2 ? '' : 'border-r'} ${i < 2 ? 'border-b md:border-b-0' : ''} ${i === 1 ? 'md:border-r' : ''}`}
            >
              <dt className="text-xs text-muted-foreground">{s.label}</dt>
              <dd className="text-3xl font-bold text-primary">{s.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </header>
  )
}
