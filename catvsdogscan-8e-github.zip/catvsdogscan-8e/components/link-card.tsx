'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'

export type LinkItem = {
  tag: string
  title: string
  description: string
  href: string
  display?: string
  ready: boolean
}

export function toAbsolute(href: string) {
  if (typeof window === 'undefined' || /^https?:/.test(href)) return href
  return new URL(href, window.location.origin).toString()
}

export function LinkCard({ item }: { item: LinkItem }) {
  const [copied, setCopied] = useState(false)
  const external = /^https?:/.test(item.href)

  const copy = async () => {
    await navigator.clipboard.writeText(toAbsolute(item.href))
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <article className="flex h-full flex-col rounded-2xl border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between gap-2">
        <span className="rounded-full bg-accent px-2.5 py-1 text-[10px] font-semibold tracking-widest text-accent-foreground uppercase">
          {item.tag}
        </span>
        <span
          className={cn(
            'inline-flex items-center gap-1.5 text-xs font-semibold',
            item.ready ? 'text-success' : 'text-warning',
          )}
        >
          <span aria-hidden="true" className={cn('size-2 rounded-full', item.ready ? 'bg-success' : 'bg-warning')} />
          {item.ready ? 'Ready' : 'Missing'}
        </span>
      </div>

      <h3 className="mt-4 text-base font-bold text-balance">{item.title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{item.description}</p>

      <p className="mt-4 rounded-lg border bg-background/60 px-3 py-2 text-xs break-all text-muted-foreground">
        {item.ready ? (item.display ?? item.href) : 'Not added yet · set it in lib/project-data.json'}
      </p>

      <div className="mt-auto flex gap-2 pt-5">
        {item.ready ? (
          <a
            href={item.href}
            {...(external ? { target: '_blank', rel: 'noreferrer' } : {})}
            className="rounded-lg bg-primary px-4 py-2 text-xs font-bold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Open<span className="sr-only"> {item.title}</span>
          </a>
        ) : (
          <span
            aria-disabled="true"
            className="cursor-not-allowed rounded-lg bg-muted px-4 py-2 text-xs font-bold text-muted-foreground"
          >
            Open
          </span>
        )}
        <button
          type="button"
          onClick={copy}
          disabled={!item.ready}
          className="rounded-lg border px-4 py-2 text-xs font-bold transition-colors hover:border-primary disabled:cursor-not-allowed disabled:opacity-50"
        >
          {copied ? 'Copied' : 'Copy'}
          <span className="sr-only"> link for {item.title}</span>
        </button>
      </div>
    </article>
  )
}

export function CopyAllButton({ items }: { items: LinkItem[] }) {
  const [copied, setCopied] = useState(false)
  const copy = async () => {
    const text = items
      .filter((i) => i.ready)
      .map((i) => `${i.title}: ${toAbsolute(i.href)}`)
      .join('\n')
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }
  return (
    <button
      type="button"
      onClick={copy}
      className="rounded-lg border bg-card px-4 py-2 text-xs font-bold transition-colors hover:border-primary"
    >
      {copied ? 'Copied to clipboard' : 'Copy all links'}
    </button>
  )
}
