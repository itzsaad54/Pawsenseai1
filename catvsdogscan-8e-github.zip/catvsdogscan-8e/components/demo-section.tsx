'use client'

import dynamic from 'next/dynamic'
import { useState } from 'react'
import { Loader2 } from 'lucide-react'

const LiveDemo = dynamic(() => import('@/components/live-demo').then((m) => m.LiveDemo), {
  ssr: false,
  loading: () => (
    <p className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
      <Loader2 className="size-4 animate-spin" aria-hidden="true" />
      Loading TensorFlow.js
    </p>
  ),
})

export function DemoSection() {
  const [loaded, setLoaded] = useState(false)

  return (
    <section aria-labelledby="demo" className="mx-auto max-w-6xl scroll-mt-8 px-4 pt-14 md:px-6">
      <h2 id="demo" className="text-2xl font-bold">
        Live demo
      </h2>
      <div className="mt-5 rounded-2xl border bg-card p-5 md:p-6">
        {loaded ? (
          <LiveDemo />
        ) : (
          <div className="flex flex-col items-center gap-3 py-12 text-center">
            <button
              type="button"
              onClick={() => setLoaded(true)}
              className="rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-opacity hover:opacity-90"
            >
              Load live demo here
            </button>
            <p className="max-w-md text-xs leading-relaxed text-muted-foreground">
              The demo loads on request so this page stays fast. The model runs in your browser, so photos are never
              uploaded anywhere.
            </p>
          </div>
        )}
      </div>
    </section>
  )
}
